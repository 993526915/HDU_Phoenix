#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include<opencv2/core.hpp>
#include<opencv2/highgui.hpp>
#include<opencv2/imgproc.hpp>
#include<opencv2/opencv.hpp>

#include<iostream>
#include<string>

#include "General\Inc\General.h"
#include "Armor\Inc\ArmorDector.h"
#include "General\Inc\opencv_extend.h"

using namespace cv;
using namespace std;

Mat src, dst;
int main()
{
	VideoCapture cap;
	ArmorDetector Arm;
	cap.open("armor.mp4");
	while (1)
	{
		cap >> src;
		if (src.empty()) break;
		//�����������ͼƬ 
		Arm.loadImg(src);
		//ɸѡ�ƹ�
		Arm.setEnemyColor(BLUE);
		int k = Arm.detect();
		waitKey(20);
	}
	waitKey(0);
	return 0;
}
